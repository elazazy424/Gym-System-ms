﻿namespace GymSystem1
{
    partial class viewCaptainsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label captain_idLabel;
            System.Windows.Forms.Label captain_nameLabel;
            System.Windows.Forms.Label addressLabel;
            System.Windows.Forms.Label phoneLabel;
            System.Windows.Forms.Label mgr_captain_idLabel;
            System.Windows.Forms.Label gym_idLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(viewCaptainsForm));
            this.dataSet4_ViewAllCaptains = new GymSystem1.DataSet4_ViewAllCaptains();
            this.gym_captainsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gym_captainsTableAdapter = new GymSystem1.DataSet4_ViewAllCaptainsTableAdapters.gym_captainsTableAdapter();
            this.tableAdapterManager = new GymSystem1.DataSet4_ViewAllCaptainsTableAdapters.TableAdapterManager();
            this.gym_captainsBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.gym_captainsBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.captain_idTextBox = new System.Windows.Forms.TextBox();
            this.captain_nameTextBox = new System.Windows.Forms.TextBox();
            this.addressTextBox = new System.Windows.Forms.TextBox();
            this.phoneTextBox = new System.Windows.Forms.TextBox();
            this.mgr_captain_idTextBox = new System.Windows.Forms.TextBox();
            this.gym_idTextBox = new System.Windows.Forms.TextBox();
            captain_idLabel = new System.Windows.Forms.Label();
            captain_nameLabel = new System.Windows.Forms.Label();
            addressLabel = new System.Windows.Forms.Label();
            phoneLabel = new System.Windows.Forms.Label();
            mgr_captain_idLabel = new System.Windows.Forms.Label();
            gym_idLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet4_ViewAllCaptains)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gym_captainsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gym_captainsBindingNavigator)).BeginInit();
            this.gym_captainsBindingNavigator.SuspendLayout();
            this.SuspendLayout();
            // 
            // captain_idLabel
            // 
            captain_idLabel.AutoSize = true;
            captain_idLabel.BackColor = System.Drawing.Color.Transparent;
            captain_idLabel.Location = new System.Drawing.Point(12, 66);
            captain_idLabel.Name = "captain_idLabel";
            captain_idLabel.Size = new System.Drawing.Size(196, 41);
            captain_idLabel.TabIndex = 1;
            captain_idLabel.Text = "captain id:";
            // 
            // captain_nameLabel
            // 
            captain_nameLabel.AutoSize = true;
            captain_nameLabel.BackColor = System.Drawing.Color.Transparent;
            captain_nameLabel.Location = new System.Drawing.Point(12, 119);
            captain_nameLabel.Name = "captain_nameLabel";
            captain_nameLabel.Size = new System.Drawing.Size(259, 41);
            captain_nameLabel.TabIndex = 3;
            captain_nameLabel.Text = "captain name:";
            // 
            // addressLabel
            // 
            addressLabel.AutoSize = true;
            addressLabel.BackColor = System.Drawing.Color.Transparent;
            addressLabel.Location = new System.Drawing.Point(12, 172);
            addressLabel.Name = "addressLabel";
            addressLabel.Size = new System.Drawing.Size(163, 41);
            addressLabel.TabIndex = 5;
            addressLabel.Text = "address:";
            // 
            // phoneLabel
            // 
            phoneLabel.AutoSize = true;
            phoneLabel.BackColor = System.Drawing.Color.Transparent;
            phoneLabel.Location = new System.Drawing.Point(12, 225);
            phoneLabel.Name = "phoneLabel";
            phoneLabel.Size = new System.Drawing.Size(136, 41);
            phoneLabel.TabIndex = 7;
            phoneLabel.Text = "phone:";
            // 
            // mgr_captain_idLabel
            // 
            mgr_captain_idLabel.AutoSize = true;
            mgr_captain_idLabel.BackColor = System.Drawing.Color.Transparent;
            mgr_captain_idLabel.Location = new System.Drawing.Point(12, 278);
            mgr_captain_idLabel.Name = "mgr_captain_idLabel";
            mgr_captain_idLabel.Size = new System.Drawing.Size(274, 41);
            mgr_captain_idLabel.TabIndex = 9;
            mgr_captain_idLabel.Text = "mgr captain id:";
            // 
            // gym_idLabel
            // 
            gym_idLabel.AutoSize = true;
            gym_idLabel.BackColor = System.Drawing.Color.Transparent;
            gym_idLabel.Location = new System.Drawing.Point(12, 331);
            gym_idLabel.Name = "gym_idLabel";
            gym_idLabel.Size = new System.Drawing.Size(144, 41);
            gym_idLabel.TabIndex = 11;
            gym_idLabel.Text = "gym id:";
            // 
            // dataSet4_ViewAllCaptains
            // 
            this.dataSet4_ViewAllCaptains.DataSetName = "DataSet4_ViewAllCaptains";
            this.dataSet4_ViewAllCaptains.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // gym_captainsBindingSource
            // 
            this.gym_captainsBindingSource.DataMember = "gym_captains";
            this.gym_captainsBindingSource.DataSource = this.dataSet4_ViewAllCaptains;
            // 
            // gym_captainsTableAdapter
            // 
            this.gym_captainsTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.gym_captainsTableAdapter = this.gym_captainsTableAdapter;
            this.tableAdapterManager.UpdateOrder = GymSystem1.DataSet4_ViewAllCaptainsTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // gym_captainsBindingNavigator
            // 
            this.gym_captainsBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.gym_captainsBindingNavigator.BindingSource = this.gym_captainsBindingSource;
            this.gym_captainsBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.gym_captainsBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.gym_captainsBindingNavigator.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.gym_captainsBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.gym_captainsBindingNavigatorSaveItem});
            this.gym_captainsBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.gym_captainsBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.gym_captainsBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.gym_captainsBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.gym_captainsBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.gym_captainsBindingNavigator.Name = "gym_captainsBindingNavigator";
            this.gym_captainsBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.gym_captainsBindingNavigator.Size = new System.Drawing.Size(754, 27);
            this.gym_captainsBindingNavigator.TabIndex = 0;
            this.gym_captainsBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(45, 24);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 27);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 27);
            // 
            // gym_captainsBindingNavigatorSaveItem
            // 
            this.gym_captainsBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.gym_captainsBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("gym_captainsBindingNavigatorSaveItem.Image")));
            this.gym_captainsBindingNavigatorSaveItem.Name = "gym_captainsBindingNavigatorSaveItem";
            this.gym_captainsBindingNavigatorSaveItem.Size = new System.Drawing.Size(29, 24);
            this.gym_captainsBindingNavigatorSaveItem.Text = "Save Data";
            this.gym_captainsBindingNavigatorSaveItem.Click += new System.EventHandler(this.gym_captainsBindingNavigatorSaveItem_Click);
            // 
            // captain_idTextBox
            // 
            this.captain_idTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.gym_captainsBindingSource, "captain_id", true));
            this.captain_idTextBox.Location = new System.Drawing.Point(292, 63);
            this.captain_idTextBox.Name = "captain_idTextBox";
            this.captain_idTextBox.Size = new System.Drawing.Size(366, 47);
            this.captain_idTextBox.TabIndex = 2;
            // 
            // captain_nameTextBox
            // 
            this.captain_nameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.gym_captainsBindingSource, "captain_name", true));
            this.captain_nameTextBox.Location = new System.Drawing.Point(292, 116);
            this.captain_nameTextBox.Name = "captain_nameTextBox";
            this.captain_nameTextBox.Size = new System.Drawing.Size(366, 47);
            this.captain_nameTextBox.TabIndex = 4;
            // 
            // addressTextBox
            // 
            this.addressTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.gym_captainsBindingSource, "address", true));
            this.addressTextBox.Location = new System.Drawing.Point(292, 169);
            this.addressTextBox.Name = "addressTextBox";
            this.addressTextBox.Size = new System.Drawing.Size(366, 47);
            this.addressTextBox.TabIndex = 6;
            // 
            // phoneTextBox
            // 
            this.phoneTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.gym_captainsBindingSource, "phone", true));
            this.phoneTextBox.Location = new System.Drawing.Point(292, 222);
            this.phoneTextBox.Name = "phoneTextBox";
            this.phoneTextBox.Size = new System.Drawing.Size(366, 47);
            this.phoneTextBox.TabIndex = 8;
            // 
            // mgr_captain_idTextBox
            // 
            this.mgr_captain_idTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.gym_captainsBindingSource, "mgr_captain_id", true));
            this.mgr_captain_idTextBox.Location = new System.Drawing.Point(292, 275);
            this.mgr_captain_idTextBox.Name = "mgr_captain_idTextBox";
            this.mgr_captain_idTextBox.Size = new System.Drawing.Size(366, 47);
            this.mgr_captain_idTextBox.TabIndex = 10;
            // 
            // gym_idTextBox
            // 
            this.gym_idTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.gym_captainsBindingSource, "gym_id", true));
            this.gym_idTextBox.Location = new System.Drawing.Point(292, 328);
            this.gym_idTextBox.Name = "gym_idTextBox";
            this.gym_idTextBox.Size = new System.Drawing.Size(366, 47);
            this.gym_idTextBox.TabIndex = 12;
            // 
            // viewCaptainsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(21F, 40F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::GymSystem1.Properties.Resources.shuffle_03;
            this.ClientSize = new System.Drawing.Size(754, 420);
            this.Controls.Add(captain_idLabel);
            this.Controls.Add(this.captain_idTextBox);
            this.Controls.Add(captain_nameLabel);
            this.Controls.Add(this.captain_nameTextBox);
            this.Controls.Add(addressLabel);
            this.Controls.Add(this.addressTextBox);
            this.Controls.Add(phoneLabel);
            this.Controls.Add(this.phoneTextBox);
            this.Controls.Add(mgr_captain_idLabel);
            this.Controls.Add(this.mgr_captain_idTextBox);
            this.Controls.Add(gym_idLabel);
            this.Controls.Add(this.gym_idTextBox);
            this.Controls.Add(this.gym_captainsBindingNavigator);
            this.Font = new System.Drawing.Font("Tahoma", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(8);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "viewCaptainsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "viewCaptainsForm";
            this.Load += new System.EventHandler(this.viewCaptainsForm_Load);
            this.Move += new System.EventHandler(this.viewCaptainsForm_Move);
            this.Resize += new System.EventHandler(this.viewCaptainsForm_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.dataSet4_ViewAllCaptains)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gym_captainsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gym_captainsBindingNavigator)).EndInit();
            this.gym_captainsBindingNavigator.ResumeLayout(false);
            this.gym_captainsBindingNavigator.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DataSet4_ViewAllCaptains dataSet4_ViewAllCaptains;
        private System.Windows.Forms.BindingSource gym_captainsBindingSource;
        private DataSet4_ViewAllCaptainsTableAdapters.gym_captainsTableAdapter gym_captainsTableAdapter;
        private DataSet4_ViewAllCaptainsTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator gym_captainsBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton gym_captainsBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox captain_idTextBox;
        private System.Windows.Forms.TextBox captain_nameTextBox;
        private System.Windows.Forms.TextBox addressTextBox;
        private System.Windows.Forms.TextBox phoneTextBox;
        private System.Windows.Forms.TextBox mgr_captain_idTextBox;
        private System.Windows.Forms.TextBox gym_idTextBox;
    }
}