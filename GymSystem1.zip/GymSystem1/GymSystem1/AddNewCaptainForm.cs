﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace GymSystem1
{
    public partial class AddNewCaptainForm : Form
    {
        public AddNewCaptainForm()
        {
            InitializeComponent();
        }

        private void AddNewCaptainForm_Move(object sender, EventArgs e)
        {
            SetForm();
        }

        private void AddNewCaptainForm_Resize(object sender, EventArgs e)
        {
            SetForm();
        }
        public void SetForm()
        {
            int x = (Screen.PrimaryScreen.Bounds.Width - this.Width) / 2;
            int y = (Screen.PrimaryScreen.Bounds.Height - this.Height) / 2;
            this.Location = new Point(x, y);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=AZAZY;Initial Catalog=GymSystem;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("insert into gym_captains values(@captain_id,@captain_name,@address,@phone,@mgr,@gym_id)", con);
                cmd.Parameters.AddWithValue("@captain_id",int.Parse(txtID.Text));
                cmd.Parameters.AddWithValue("@captain_name", txtName.Text);
                cmd.Parameters.AddWithValue("@address", txtAdress.Text);
                cmd.Parameters.AddWithValue("@phone", txtPhone.Text);
                cmd.Parameters.AddWithValue("@mgr", txtManager.Text);
                cmd.Parameters.AddWithValue("@gym_id", txtGymID.Text);
                con.Open();
                int rowff = cmd.ExecuteNonQuery();
                if (rowff > 0)
                {
                    MessageBox.Show("Added succefully");
                }
                else
                {
                    MessageBox.Show("Not added");
                }
                con.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtID.Text = "";
            txtAdress.Text = "";
            txtGymID.Text = "";
            txtManager.Text = "";
            txtPhone.Text = "";
            txtName.Text = "";
        }
    }
}
