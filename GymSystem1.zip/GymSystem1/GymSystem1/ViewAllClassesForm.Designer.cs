﻿namespace GymSystem1
{
    partial class ViewAllClassesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label workout_class_idLabel;
            System.Windows.Forms.Label workOutClass_nameLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ViewAllClassesForm));
            this.dataSet5_viewWorkoutClass = new GymSystem1.DataSet5_viewWorkoutClass();
            this.workout_classBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.workout_classTableAdapter = new GymSystem1.DataSet5_viewWorkoutClassTableAdapters.workout_classTableAdapter();
            this.tableAdapterManager = new GymSystem1.DataSet5_viewWorkoutClassTableAdapters.TableAdapterManager();
            this.workout_classBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.workout_classBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.workout_class_idTextBox = new System.Windows.Forms.TextBox();
            this.workOutClass_nameTextBox = new System.Windows.Forms.TextBox();
            workout_class_idLabel = new System.Windows.Forms.Label();
            workOutClass_nameLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet5_viewWorkoutClass)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.workout_classBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.workout_classBindingNavigator)).BeginInit();
            this.workout_classBindingNavigator.SuspendLayout();
            this.SuspendLayout();
            // 
            // workout_class_idLabel
            // 
            workout_class_idLabel.AutoSize = true;
            workout_class_idLabel.BackColor = System.Drawing.Color.Transparent;
            workout_class_idLabel.Location = new System.Drawing.Point(22, 66);
            workout_class_idLabel.Name = "workout_class_idLabel";
            workout_class_idLabel.Size = new System.Drawing.Size(299, 40);
            workout_class_idLabel.TabIndex = 1;
            workout_class_idLabel.Text = "workout class id:";
            // 
            // workOutClass_nameLabel
            // 
            workOutClass_nameLabel.AutoSize = true;
            workOutClass_nameLabel.BackColor = System.Drawing.Color.Transparent;
            workOutClass_nameLabel.Location = new System.Drawing.Point(22, 119);
            workOutClass_nameLabel.Name = "workOutClass_nameLabel";
            workOutClass_nameLabel.Size = new System.Drawing.Size(385, 40);
            workOutClass_nameLabel.TabIndex = 3;
            workOutClass_nameLabel.Text = "Work Out Class name:";
            // 
            // dataSet5_viewWorkoutClass
            // 
            this.dataSet5_viewWorkoutClass.DataSetName = "DataSet5_viewWorkoutClass";
            this.dataSet5_viewWorkoutClass.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // workout_classBindingSource
            // 
            this.workout_classBindingSource.DataMember = "workout_class";
            this.workout_classBindingSource.DataSource = this.dataSet5_viewWorkoutClass;
            // 
            // workout_classTableAdapter
            // 
            this.workout_classTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.UpdateOrder = GymSystem1.DataSet5_viewWorkoutClassTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.workout_classTableAdapter = this.workout_classTableAdapter;
            // 
            // workout_classBindingNavigator
            // 
            this.workout_classBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.workout_classBindingNavigator.BindingSource = this.workout_classBindingSource;
            this.workout_classBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.workout_classBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.workout_classBindingNavigator.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.workout_classBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.workout_classBindingNavigatorSaveItem});
            this.workout_classBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.workout_classBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.workout_classBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.workout_classBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.workout_classBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.workout_classBindingNavigator.Name = "workout_classBindingNavigator";
            this.workout_classBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.workout_classBindingNavigator.Size = new System.Drawing.Size(700, 31);
            this.workout_classBindingNavigator.TabIndex = 0;
            this.workout_classBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(29, 28);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(45, 28);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(29, 28);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(29, 28);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(29, 28);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 31);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 27);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 31);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(29, 28);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(29, 28);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 31);
            // 
            // workout_classBindingNavigatorSaveItem
            // 
            this.workout_classBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.workout_classBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("workout_classBindingNavigatorSaveItem.Image")));
            this.workout_classBindingNavigatorSaveItem.Name = "workout_classBindingNavigatorSaveItem";
            this.workout_classBindingNavigatorSaveItem.Size = new System.Drawing.Size(29, 28);
            this.workout_classBindingNavigatorSaveItem.Text = "Save Data";
            this.workout_classBindingNavigatorSaveItem.Click += new System.EventHandler(this.workout_classBindingNavigatorSaveItem_Click_1);
            // 
            // workout_class_idTextBox
            // 
            this.workout_class_idTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.workout_classBindingSource, "workout_class_id", true));
            this.workout_class_idTextBox.Location = new System.Drawing.Point(424, 63);
            this.workout_class_idTextBox.Name = "workout_class_idTextBox";
            this.workout_class_idTextBox.Size = new System.Drawing.Size(264, 47);
            this.workout_class_idTextBox.TabIndex = 2;
            // 
            // workOutClass_nameTextBox
            // 
            this.workOutClass_nameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.workout_classBindingSource, "WorkOutClass_name", true));
            this.workOutClass_nameTextBox.Location = new System.Drawing.Point(424, 116);
            this.workOutClass_nameTextBox.Name = "workOutClass_nameTextBox";
            this.workOutClass_nameTextBox.Size = new System.Drawing.Size(264, 47);
            this.workOutClass_nameTextBox.TabIndex = 4;
            // 
            // ViewAllClassesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(21F, 40F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::GymSystem1.Properties.Resources.shuffle_03;
            this.ClientSize = new System.Drawing.Size(700, 204);
            this.Controls.Add(workout_class_idLabel);
            this.Controls.Add(this.workout_class_idTextBox);
            this.Controls.Add(workOutClass_nameLabel);
            this.Controls.Add(this.workOutClass_nameTextBox);
            this.Controls.Add(this.workout_classBindingNavigator);
            this.Font = new System.Drawing.Font("Tahoma", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(8);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ViewAllClassesForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ViewAllClassesForm";
            this.Load += new System.EventHandler(this.ViewAllClassesForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataSet5_viewWorkoutClass)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.workout_classBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.workout_classBindingNavigator)).EndInit();
            this.workout_classBindingNavigator.ResumeLayout(false);
            this.workout_classBindingNavigator.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DataSet5_viewWorkoutClass dataSet5_viewWorkoutClass;
        private System.Windows.Forms.BindingSource workout_classBindingSource;
        private DataSet5_viewWorkoutClassTableAdapters.workout_classTableAdapter workout_classTableAdapter;
        private DataSet5_viewWorkoutClassTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator workout_classBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton workout_classBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox workout_class_idTextBox;
        private System.Windows.Forms.TextBox workOutClass_nameTextBox;
    }
}