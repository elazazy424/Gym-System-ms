﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymSystem1
{
    public partial class TrainerForm : Form
    {
        public TrainerForm()
        {
            InitializeComponent();
        }

        private void addNewCaptainToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddNewTrainee add = new AddNewTrainee();
            add.ShowDialog();
        }

        private void updateCaptainToolStripMenuItem_Click(object sender, EventArgs e)
        {
            updateNewTrainee add = new updateNewTrainee();
            add.ShowDialog();
        }

        private void searchCaptainToolStripMenuItem_Click(object sender, EventArgs e)
        {
            searchNewTrainee add = new searchNewTrainee();
            add.ShowDialog();
        }

        private void viewCaptainToolStripMenuItem_Click(object sender, EventArgs e)
        {
            viewallTrainee v = new viewallTrainee();
            v.ShowDialog(); 
        }

        private void addMembershipToolStripMenuItem_Click(object sender, EventArgs e)
        {
            addMembershipForm add = new addMembershipForm();
            add.ShowDialog();  
        }

        private void searchForAMembershipToolStripMenuItem_Click(object sender, EventArgs e)
        {
            searchForAMembershipForm f = new searchForAMembershipForm();
            f.ShowDialog(); 
        }

        

        private void gymMembershipsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void updateAMembershipToolStripMenuItem_Click(object sender, EventArgs e)
        {
            updateAMembershipForm f = new updateAMembershipForm();
            f.ShowDialog(); 
        }

        private void viewAllMembershipsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            viewAllMembershipsForm f = new viewAllMembershipsForm();
            f.ShowDialog(); 
        }
    }
}
