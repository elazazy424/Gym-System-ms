﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GymSystem1
{
    public partial class DeleteWorkOutClassForm : Form
    {
        public DeleteWorkOutClassForm()
        {
            InitializeComponent();
        }

        private void DeleteWorkOutClassForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'gymSystemDataSet4.workout_class' table. You can move, or remove it, as needed.
            this.workout_classTableAdapter.Fill(this.gymSystemDataSet4.workout_class);

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=AZAZY;Initial Catalog=GymSystem;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("select WorkOutClass_name from workout_class where workout_class_id = @id", con);
            cmd.Parameters.AddWithValue("@id", comboBox1.Text);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                txtName.Text = dr[0].ToString();
              
            }
            else
            {
                MessageBox.Show("error");
            }
            con.Close();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=AZAZY;Initial Catalog=GymSystem;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("delete from workout_class  where workout_class_id=@id", con);
                cmd.Parameters.AddWithValue("@id", comboBox1.Text);
                con.Open();
                int rowff = cmd.ExecuteNonQuery();
                if (rowff > 0)
                {
                    MessageBox.Show("Deleted");
                }
                else
                {
                    MessageBox.Show("error");
                }
                con.Close();
                //this.gym_captainsTableAdapter.Fill(this.gymSystemDataSet2.gym_captains);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }
    }
}
