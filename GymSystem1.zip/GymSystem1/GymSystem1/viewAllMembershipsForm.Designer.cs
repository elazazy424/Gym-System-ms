﻿namespace GymSystem1
{
    partial class viewAllMembershipsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(viewAllMembershipsForm));
            System.Windows.Forms.Label membership_idLabel;
            System.Windows.Forms.Label start_dateLabel;
            System.Windows.Forms.Label end_dateLabel;
            System.Windows.Forms.Label durationLabel;
            System.Windows.Forms.Label gym_idLabel;
            System.Windows.Forms.Label trainee_phone_numberLabel;
            this.dataSet14_viewAllMemberships = new GymSystem1.DataSet14_viewAllMemberships();
            this.gym_membershipsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gym_membershipsTableAdapter = new GymSystem1.DataSet14_viewAllMembershipsTableAdapters.gym_membershipsTableAdapter();
            this.tableAdapterManager = new GymSystem1.DataSet14_viewAllMembershipsTableAdapters.TableAdapterManager();
            this.gym_membershipsBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.gym_membershipsBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.membership_idTextBox = new System.Windows.Forms.TextBox();
            this.start_dateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.end_dateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.durationTextBox = new System.Windows.Forms.TextBox();
            this.gym_idTextBox = new System.Windows.Forms.TextBox();
            this.trainee_phone_numberTextBox = new System.Windows.Forms.TextBox();
            membership_idLabel = new System.Windows.Forms.Label();
            start_dateLabel = new System.Windows.Forms.Label();
            end_dateLabel = new System.Windows.Forms.Label();
            durationLabel = new System.Windows.Forms.Label();
            gym_idLabel = new System.Windows.Forms.Label();
            trainee_phone_numberLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet14_viewAllMemberships)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gym_membershipsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gym_membershipsBindingNavigator)).BeginInit();
            this.gym_membershipsBindingNavigator.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataSet14_viewAllMemberships
            // 
            this.dataSet14_viewAllMemberships.DataSetName = "DataSet14_viewAllMemberships";
            this.dataSet14_viewAllMemberships.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // gym_membershipsBindingSource
            // 
            this.gym_membershipsBindingSource.DataMember = "gym_memberships";
            this.gym_membershipsBindingSource.DataSource = this.dataSet14_viewAllMemberships;
            // 
            // gym_membershipsTableAdapter
            // 
            this.gym_membershipsTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.gym_membershipsTableAdapter = this.gym_membershipsTableAdapter;
            this.tableAdapterManager.UpdateOrder = GymSystem1.DataSet14_viewAllMembershipsTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // gym_membershipsBindingNavigator
            // 
            this.gym_membershipsBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.gym_membershipsBindingNavigator.BindingSource = this.gym_membershipsBindingSource;
            this.gym_membershipsBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.gym_membershipsBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.gym_membershipsBindingNavigator.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.gym_membershipsBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.gym_membershipsBindingNavigatorSaveItem});
            this.gym_membershipsBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.gym_membershipsBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.gym_membershipsBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.gym_membershipsBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.gym_membershipsBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.gym_membershipsBindingNavigator.Name = "gym_membershipsBindingNavigator";
            this.gym_membershipsBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.gym_membershipsBindingNavigator.Size = new System.Drawing.Size(915, 31);
            this.gym_membershipsBindingNavigator.TabIndex = 0;
            this.gym_membershipsBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(29, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(29, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 27);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(45, 20);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(29, 28);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // gym_membershipsBindingNavigatorSaveItem
            // 
            this.gym_membershipsBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.gym_membershipsBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("gym_membershipsBindingNavigatorSaveItem.Image")));
            this.gym_membershipsBindingNavigatorSaveItem.Name = "gym_membershipsBindingNavigatorSaveItem";
            this.gym_membershipsBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 23);
            this.gym_membershipsBindingNavigatorSaveItem.Text = "Save Data";
            this.gym_membershipsBindingNavigatorSaveItem.Click += new System.EventHandler(this.gym_membershipsBindingNavigatorSaveItem_Click);
            // 
            // membership_idLabel
            // 
            membership_idLabel.AutoSize = true;
            membership_idLabel.BackColor = System.Drawing.Color.Transparent;
            membership_idLabel.Location = new System.Drawing.Point(34, 86);
            membership_idLabel.Name = "membership_idLabel";
            membership_idLabel.Size = new System.Drawing.Size(282, 41);
            membership_idLabel.TabIndex = 1;
            membership_idLabel.Text = "membership id:";
            // 
            // membership_idTextBox
            // 
            this.membership_idTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.gym_membershipsBindingSource, "membership_id", true));
            this.membership_idTextBox.Location = new System.Drawing.Point(449, 83);
            this.membership_idTextBox.Name = "membership_idTextBox";
            this.membership_idTextBox.Size = new System.Drawing.Size(438, 47);
            this.membership_idTextBox.TabIndex = 2;
            // 
            // start_dateLabel
            // 
            start_dateLabel.AutoSize = true;
            start_dateLabel.BackColor = System.Drawing.Color.Transparent;
            start_dateLabel.Location = new System.Drawing.Point(34, 167);
            start_dateLabel.Name = "start_dateLabel";
            start_dateLabel.Size = new System.Drawing.Size(196, 41);
            start_dateLabel.TabIndex = 3;
            start_dateLabel.Text = "start date:";
            // 
            // start_dateDateTimePicker
            // 
            this.start_dateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.gym_membershipsBindingSource, "start_date", true));
            this.start_dateDateTimePicker.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.start_dateDateTimePicker.Location = new System.Drawing.Point(449, 149);
            this.start_dateDateTimePicker.Name = "start_dateDateTimePicker";
            this.start_dateDateTimePicker.Size = new System.Drawing.Size(438, 35);
            this.start_dateDateTimePicker.TabIndex = 4;
            // 
            // end_dateLabel
            // 
            end_dateLabel.AutoSize = true;
            end_dateLabel.BackColor = System.Drawing.Color.Transparent;
            end_dateLabel.Location = new System.Drawing.Point(34, 226);
            end_dateLabel.Name = "end_dateLabel";
            end_dateLabel.Size = new System.Drawing.Size(178, 41);
            end_dateLabel.TabIndex = 5;
            end_dateLabel.Text = "end date:";
            // 
            // end_dateDateTimePicker
            // 
            this.end_dateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.gym_membershipsBindingSource, "end_date", true));
            this.end_dateDateTimePicker.Font = new System.Drawing.Font("Tahoma", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.end_dateDateTimePicker.Location = new System.Drawing.Point(449, 220);
            this.end_dateDateTimePicker.Name = "end_dateDateTimePicker";
            this.end_dateDateTimePicker.Size = new System.Drawing.Size(438, 35);
            this.end_dateDateTimePicker.TabIndex = 6;
            // 
            // durationLabel
            // 
            durationLabel.AutoSize = true;
            durationLabel.BackColor = System.Drawing.Color.Transparent;
            durationLabel.Location = new System.Drawing.Point(34, 297);
            durationLabel.Name = "durationLabel";
            durationLabel.Size = new System.Drawing.Size(175, 41);
            durationLabel.TabIndex = 7;
            durationLabel.Text = "duration:";
            // 
            // durationTextBox
            // 
            this.durationTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.gym_membershipsBindingSource, "duration", true));
            this.durationTextBox.Location = new System.Drawing.Point(449, 281);
            this.durationTextBox.Name = "durationTextBox";
            this.durationTextBox.Size = new System.Drawing.Size(438, 47);
            this.durationTextBox.TabIndex = 8;
            // 
            // gym_idLabel
            // 
            gym_idLabel.AutoSize = true;
            gym_idLabel.BackColor = System.Drawing.Color.Transparent;
            gym_idLabel.Location = new System.Drawing.Point(34, 369);
            gym_idLabel.Name = "gym_idLabel";
            gym_idLabel.Size = new System.Drawing.Size(144, 41);
            gym_idLabel.TabIndex = 9;
            gym_idLabel.Text = "gym id:";
            // 
            // gym_idTextBox
            // 
            this.gym_idTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.gym_membershipsBindingSource, "gym_id", true));
            this.gym_idTextBox.Location = new System.Drawing.Point(449, 363);
            this.gym_idTextBox.Name = "gym_idTextBox";
            this.gym_idTextBox.Size = new System.Drawing.Size(438, 47);
            this.gym_idTextBox.TabIndex = 10;
            // 
            // trainee_phone_numberLabel
            // 
            trainee_phone_numberLabel.AutoSize = true;
            trainee_phone_numberLabel.BackColor = System.Drawing.Color.Transparent;
            trainee_phone_numberLabel.Location = new System.Drawing.Point(34, 445);
            trainee_phone_numberLabel.Name = "trainee_phone_numberLabel";
            trainee_phone_numberLabel.Size = new System.Drawing.Size(409, 41);
            trainee_phone_numberLabel.TabIndex = 11;
            trainee_phone_numberLabel.Text = "trainee phone number:";
            // 
            // trainee_phone_numberTextBox
            // 
            this.trainee_phone_numberTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.gym_membershipsBindingSource, "trainee_phone_number", true));
            this.trainee_phone_numberTextBox.Location = new System.Drawing.Point(449, 439);
            this.trainee_phone_numberTextBox.Name = "trainee_phone_numberTextBox";
            this.trainee_phone_numberTextBox.Size = new System.Drawing.Size(438, 47);
            this.trainee_phone_numberTextBox.TabIndex = 12;
            // 
            // viewAllMembershipsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(21F, 40F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::GymSystem1.Properties.Resources.shuffle_03;
            this.ClientSize = new System.Drawing.Size(915, 536);
            this.Controls.Add(membership_idLabel);
            this.Controls.Add(this.membership_idTextBox);
            this.Controls.Add(start_dateLabel);
            this.Controls.Add(this.start_dateDateTimePicker);
            this.Controls.Add(end_dateLabel);
            this.Controls.Add(this.end_dateDateTimePicker);
            this.Controls.Add(durationLabel);
            this.Controls.Add(this.durationTextBox);
            this.Controls.Add(gym_idLabel);
            this.Controls.Add(this.gym_idTextBox);
            this.Controls.Add(trainee_phone_numberLabel);
            this.Controls.Add(this.trainee_phone_numberTextBox);
            this.Controls.Add(this.gym_membershipsBindingNavigator);
            this.Font = new System.Drawing.Font("Tahoma", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(8);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "viewAllMembershipsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "viewAllMembershipsForm";
            this.Load += new System.EventHandler(this.viewAllMembershipsForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataSet14_viewAllMemberships)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gym_membershipsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gym_membershipsBindingNavigator)).EndInit();
            this.gym_membershipsBindingNavigator.ResumeLayout(false);
            this.gym_membershipsBindingNavigator.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DataSet14_viewAllMemberships dataSet14_viewAllMemberships;
        private System.Windows.Forms.BindingSource gym_membershipsBindingSource;
        private DataSet14_viewAllMembershipsTableAdapters.gym_membershipsTableAdapter gym_membershipsTableAdapter;
        private DataSet14_viewAllMembershipsTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator gym_membershipsBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton gym_membershipsBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox membership_idTextBox;
        private System.Windows.Forms.DateTimePicker start_dateDateTimePicker;
        private System.Windows.Forms.DateTimePicker end_dateDateTimePicker;
        private System.Windows.Forms.TextBox durationTextBox;
        private System.Windows.Forms.TextBox gym_idTextBox;
        private System.Windows.Forms.TextBox trainee_phone_numberTextBox;
    }
}