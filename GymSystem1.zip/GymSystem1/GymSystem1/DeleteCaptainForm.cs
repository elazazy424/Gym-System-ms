﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GymSystem1
{
    public partial class DeleteCaptainForm : Form
    {
        public DeleteCaptainForm()
        {
            InitializeComponent();
        }

        private void DeleteCaptainForm_Move(object sender, EventArgs e)
        {
            SetForm();
;        }

        private void DeleteCaptainForm_Resize(object sender, EventArgs e)
        {
            SetForm();
        }
        public void SetForm()
        {
            int x = (Screen.PrimaryScreen.Bounds.Width - this.Width) / 2;
            int y = (Screen.PrimaryScreen.Bounds.Height - this.Height) / 2;
            this.Location = new Point(x, y);
        }

        private void DeleteCaptainForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'gymSystemDataSet2.gym_captains' table. You can move, or remove it, as needed.
            this.gym_captainsTableAdapter.Fill(this.gymSystemDataSet2.gym_captains);

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(@"Data Source=AZAZY;Initial Catalog=GymSystem;Integrated Security=True");
            SqlCommand cmd = new SqlCommand("select captain_name , address , phone from gym_captains where captain_id = @id",con);
            cmd.Parameters.AddWithValue("@id", comboBox1.Text);
            con.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                txtName.Text = dr[0].ToString();
                txtAddress.Text = dr[1].ToString(); 
                txtPhone.Text  = dr[2].ToString();
            }
            else
            {
                MessageBox.Show("error");
            }
            con.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtAddress.Text = "";
            txtName.Text = "";
            txtPhone.Text = "";
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=AZAZY;Initial Catalog=GymSystem;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("delete from gym_captains where captain_id=@id",con);
                cmd.Parameters.AddWithValue("@id", comboBox1.Text);
                con.Open();
                int rowff = cmd.ExecuteNonQuery();
                if (rowff > 0)
                {
                    MessageBox.Show("Deleted");
                }
                else
                {
                    MessageBox.Show("error");
                }
                con.Close();
                //this.gym_captainsTableAdapter.Fill(this.gymSystemDataSet2.gym_captains);
            }
            catch (Exception ex )
            {

                MessageBox.Show(ex.Message);
            }
        }
    }
}
