﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GymSystem1
{
    public partial class AddNewTrainee : Form
    {
        public AddNewTrainee()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=AZAZY;Initial Catalog=GymSystem;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("insert into trainees values(@ph , @fn , @mn , @ln , @bd , @address , @email)", con);
                cmd.Parameters.AddWithValue("@ph", txtPhone.Text);
                cmd.Parameters.AddWithValue("@fn", txtFirstName.Text);
                cmd.Parameters.AddWithValue("@mn", txtMidName.Text);
                cmd.Parameters.AddWithValue("@ln", txtLastName.Text);
                cmd.Parameters.AddWithValue("@bd", txtBirth.Text);
                cmd.Parameters.AddWithValue("@address", txtAddress.Text);
                cmd.Parameters.AddWithValue("@email", txtEmail.Text);
                con.Open();
                int rowff = cmd.ExecuteNonQuery();
                if (rowff > 0)
                {
                    MessageBox.Show("added");
                }
                else
                {
                    MessageBox.Show("error");
                }
                con.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtAddress.Text = "";
            txtBirth.Text = "";
            txtEmail.Text = "";
            txtFirstName.Text = "";
            txtLastName.Text = "";
            txtMidName.Text = "";
            txtPhone.Text = "";
        }
    }
}
