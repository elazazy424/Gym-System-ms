﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymSystem1
{
    public partial class ViewAllClassesForm : Form
    {
        public ViewAllClassesForm()
        {
            InitializeComponent();
        }

        private void workout_classBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.workout_classBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dataSet5_viewWorkoutClass);

        }

        private void workout_classBindingNavigatorSaveItem_Click_1(object sender, EventArgs e)
        {
            this.Validate();
            this.workout_classBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dataSet5_viewWorkoutClass);

        }

        private void ViewAllClassesForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataSet5_viewWorkoutClass.workout_class' table. You can move, or remove it, as needed.
            this.workout_classTableAdapter.Fill(this.dataSet5_viewWorkoutClass.workout_class);

        }
    }
}
