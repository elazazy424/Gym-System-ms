﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace GymSystem1
{
    public partial class updateNewTrainee : Form
    {
        public updateNewTrainee()
        {
            InitializeComponent();
        }

        private void updateNewTrainee_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'gymSystemDataSet7.trainees' table. You can move, or remove it, as needed.
            this.traineesTableAdapter.Fill(this.gymSystemDataSet7.trainees);

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=AZAZY;Initial Catalog=GymSystem;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("select first_name,mid_name,last_name,birth_date,Adress,Email  from trainees where phone_number=@id", con);
                cmd.Parameters.AddWithValue("@id", comboBox1.Text);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    txtFirstName.Text = dr[0].ToString();
                    txtMidName.Text= dr[1].ToString();
                    txtLastName.Text = dr[2].ToString();
                    txtBirthDate.Text= dr[3].ToString();    
                    txtAddress.Text= dr[4].ToString();  
                    txtEmail.Text= dr[5].ToString();    
                }
                else
                {
                    MessageBox.Show("error");
                }
                con.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=AZAZY;Initial Catalog=GymSystem;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("update trainees set adress = @address , Email = @email where phone_number = @id", con);
                cmd.Parameters.AddWithValue("@id", int.Parse(comboBox1.Text));
                cmd.Parameters.AddWithValue("@address", txtAddress.Text);
                cmd.Parameters.AddWithValue("@email", txtEmail.Text);
                con.Open();
                int rowff = cmd.ExecuteNonQuery();
                if (rowff > 0)
                {
                    MessageBox.Show("updated");
                }
                else
                {
                    MessageBox.Show("error");
                }
                con.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtAddress.Text = "";
            txtBirthDate.Text = "";
            txtEmail.Text = "";
            txtFirstName.Text = "";
            txtLastName.Text = "";
            txtMidName.Text = "";
        }
    }
}
