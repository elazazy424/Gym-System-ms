﻿namespace GymSystem1
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.lblGym = new System.Windows.Forms.Label();
            this.btnCaptain = new System.Windows.Forms.Button();
            this.btnTrainer = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblGym
            // 
            this.lblGym.AutoSize = true;
            this.lblGym.BackColor = System.Drawing.Color.Transparent;
            this.lblGym.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGym.Location = new System.Drawing.Point(188, 18);
            this.lblGym.Name = "lblGym";
            this.lblGym.Size = new System.Drawing.Size(315, 48);
            this.lblGym.TabIndex = 0;
            this.lblGym.Text = "Napoleon Gym";
            // 
            // btnCaptain
            // 
            this.btnCaptain.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnCaptain.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCaptain.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCaptain.ForeColor = System.Drawing.Color.White;
            this.btnCaptain.Location = new System.Drawing.Point(85, 128);
            this.btnCaptain.Name = "btnCaptain";
            this.btnCaptain.Size = new System.Drawing.Size(189, 79);
            this.btnCaptain.TabIndex = 1;
            this.btnCaptain.Text = "Captain";
            this.toolTip1.SetToolTip(this.btnCaptain, "Captain Settings");
            this.btnCaptain.UseVisualStyleBackColor = false;
            this.btnCaptain.Click += new System.EventHandler(this.btnCaptain_Click);
            // 
            // btnTrainer
            // 
            this.btnTrainer.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnTrainer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTrainer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnTrainer.ForeColor = System.Drawing.Color.White;
            this.btnTrainer.Location = new System.Drawing.Point(348, 128);
            this.btnTrainer.Name = "btnTrainer";
            this.btnTrainer.Size = new System.Drawing.Size(189, 79);
            this.btnTrainer.TabIndex = 2;
            this.btnTrainer.Text = "Trainee";
            this.toolTip1.SetToolTip(this.btnTrainer, "Trainer Settings");
            this.btnTrainer.UseVisualStyleBackColor = false;
            this.btnTrainer.Click += new System.EventHandler(this.btnTrainer_Click);
            // 
            // toolTip1
            // 
            this.toolTip1.IsBalloon = true;
            this.toolTip1.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnExit.ForeColor = System.Drawing.Color.White;
            this.btnExit.Location = new System.Drawing.Point(469, 277);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(160, 64);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "Exit";
            this.toolTip1.SetToolTip(this.btnExit, "Trainer Settings");
            this.btnExit.UseVisualStyleBackColor = false;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(21F, 40F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::GymSystem1.Properties.Resources.landing;
            this.ClientSize = new System.Drawing.Size(632, 344);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnTrainer);
            this.Controls.Add(this.btnCaptain);
            this.Controls.Add(this.lblGym);
            this.Font = new System.Drawing.Font("Tahoma", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(8);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main Form";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.Move += new System.EventHandler(this.MainForm_Move);
            this.Resize += new System.EventHandler(this.MainForm_Resize);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblGym;
        private System.Windows.Forms.Button btnCaptain;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button btnTrainer;
        private System.Windows.Forms.Button btnExit;
    }
}

