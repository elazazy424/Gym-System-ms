﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GymSystem1
{
    public partial class CaptainForm : Form
    {
        public CaptainForm()
        {
            InitializeComponent();
        }

        private void CaptainForm_Move(object sender, EventArgs e)
        {
            SetForm();
        }

        private void CaptainForm_Resize(object sender, EventArgs e)
        {
            SetForm();
        }
        public void SetForm()
        {
            int x = (Screen.PrimaryScreen.Bounds.Width - this.Width) / 2;
            int y = (Screen.PrimaryScreen.Bounds.Height - this.Height) / 2;
            this.Location = new Point(x, y);
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtID.Text = "";
            txtName.Text = "";
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {
            Application.Exit(); 
        }

        private void btnBackMainForm_Click(object sender, EventArgs e)
        {
            MainForm m = new MainForm();
            m.ShowDialog();
            this.Hide(); 
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=AZAZY;Initial Catalog=GymSystem;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("select *from gym_captains where captain_name='" + txtName.Text + "'and captain_id='" + int.Parse(txtID.Text) + "'", con);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    InfoForm IF = new InfoForm();
                    IF.ShowDialog();
                   
                }
                else
                {
                    MessageBox.Show("Incorrect username or password please try again");
                }
                con.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            
           
        }
    }
}
