﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GymSystem1
{
    public partial class InfoForm : Form
    {
        public InfoForm()
        {
            InitializeComponent();
        }
        private void menuStrip1_Move(object sender, EventArgs e)
        {
            SetForm();
        }

        private void menuStrip1_Resize(object sender, EventArgs e)
        {
            SetForm();
        }
        public void SetForm()
        {
            int x = (Screen.PrimaryScreen.Bounds.Width - this.Width) / 2;
            int y = (Screen.PrimaryScreen.Bounds.Height - this.Height) / 2;
            this.Location = new Point(x, y);
        }

        private void addNewCaptainToolStripMenuItem_Click(object sender, EventArgs e)
        {
           AddNewCaptainForm add = new AddNewCaptainForm();
           add.ShowDialog();
           

        }

        private void updateCaptainToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UpdateCaptainForm uc = new UpdateCaptainForm();
            uc.ShowDialog();
        }

        private void InfoForm_Resize(object sender, EventArgs e)
        {

        }

        private void InfoForm_Move(object sender, EventArgs e)
        {

        }

        private void deleteCaptainToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteCaptainForm delete = new DeleteCaptainForm();
            delete.ShowDialog();
        }

        private void searchCaptainToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SearchCaptainForm search = new SearchCaptainForm();
            search.ShowDialog();
        }

        private void viewCaptainToolStripMenuItem_Click(object sender, EventArgs e)
        {
            viewCaptainsForm view = new viewCaptainsForm();
            view.ShowDialog();
        }

        private void addNewTrainerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddWorkOutClassForm aworkout = new AddWorkOutClassForm();
            aworkout.ShowDialog();
        }

        private void updateTrainerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DeleteWorkOutClassForm dworkout = new DeleteWorkOutClassForm();
            dworkout.ShowDialog();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            ViewAllClassesForm viewAll = new ViewAllClassesForm();
            viewAll.ShowDialog();
        }

        private void dToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void addGymToolStripMenuItem_Click(object sender, EventArgs e)
        {
            addgymForm add = new addgymForm();
            add.ShowDialog();   
        }

        private void addGymAddressToolStripMenuItem_Click(object sender, EventArgs e)
        {
            addgymAddressForm add = new addgymAddressForm();
            add.ShowDialog();
        }

        private void removeGymAddressToolStripMenuItem_Click(object sender, EventArgs e)
        {
            RemovegymAddressForm Remove = new RemovegymAddressForm();
            Remove.ShowDialog();
        }
    }
}
