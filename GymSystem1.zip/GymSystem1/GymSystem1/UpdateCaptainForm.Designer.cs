﻿namespace GymSystem1
{
    partial class UpdateCaptainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UpdateCaptainForm));
            this.gymcaptainsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gymSystemDataSet = new GymSystem1.GymSystemDataSet();
            this.connectionDbDataSet = new GymSystem1.ConnectionDbDataSet();
            this.connectionDbDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.gym_captainsTableAdapter = new GymSystem1.GymSystemDataSetTableAdapters.gym_captainsTableAdapter();
            this.gymSystemDataSet1 = new GymSystem1.GymSystemDataSet1();
            this.gymcaptainsBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.gym_captainsTableAdapter1 = new GymSystem1.GymSystemDataSet1TableAdapters.gym_captainsTableAdapter();
            this.gymSystemDataSet6 = new GymSystem1.GymSystemDataSet6();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.gymcaptainsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gymSystemDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.connectionDbDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.connectionDbDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gymSystemDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gymcaptainsBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gymSystemDataSet6)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // gymcaptainsBindingSource
            // 
            this.gymcaptainsBindingSource.DataMember = "gym_captains";
            this.gymcaptainsBindingSource.DataSource = this.gymSystemDataSet;
            // 
            // gymSystemDataSet
            // 
            this.gymSystemDataSet.DataSetName = "GymSystemDataSet";
            this.gymSystemDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // connectionDbDataSet
            // 
            this.connectionDbDataSet.DataSetName = "ConnectionDbDataSet";
            this.connectionDbDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // connectionDbDataSetBindingSource
            // 
            this.connectionDbDataSetBindingSource.DataSource = this.connectionDbDataSet;
            this.connectionDbDataSetBindingSource.Position = 0;
            // 
            // gym_captainsTableAdapter
            // 
            this.gym_captainsTableAdapter.ClearBeforeFill = true;
            // 
            // gymSystemDataSet1
            // 
            this.gymSystemDataSet1.DataSetName = "GymSystemDataSet1";
            this.gymSystemDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // gymcaptainsBindingSource1
            // 
            this.gymcaptainsBindingSource1.DataMember = "gym_captains";
            this.gymcaptainsBindingSource1.DataSource = this.gymSystemDataSet1;
            // 
            // gym_captainsTableAdapter1
            // 
            this.gym_captainsTableAdapter1.ClearBeforeFill = true;
            // 
            // gymSystemDataSet6
            // 
            this.gymSystemDataSet6.DataSetName = "GymSystemDataSet6";
            this.gymSystemDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(72, 108);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 40);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID : ";
            // 
            // comboBox1
            // 
            this.comboBox1.DataSource = this.gymcaptainsBindingSource;
            this.comboBox1.DisplayMember = "captain_id";
            this.comboBox1.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(247, 111);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(295, 41);
            this.comboBox1.TabIndex = 1;
            this.comboBox1.ValueMember = "captain_id";
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(72, 175);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(145, 40);
            this.label2.TabIndex = 2;
            this.label2.Text = "Name : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(72, 255);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(182, 40);
            this.label3.TabIndex = 4;
            this.label3.Text = "Address : ";
            // 
            // txtAddress
            // 
            this.txtAddress.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAddress.Location = new System.Drawing.Point(247, 255);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(295, 40);
            this.txtAddress.TabIndex = 5;
            // 
            // btnUpdate
            // 
            this.btnUpdate.BackColor = System.Drawing.Color.Transparent;
            this.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnUpdate.ForeColor = System.Drawing.Color.White;
            this.btnUpdate.Location = new System.Drawing.Point(47, 445);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(245, 62);
            this.btnUpdate.TabIndex = 7;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.Transparent;
            this.btnClear.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnClear.ForeColor = System.Drawing.Color.White;
            this.btnClear.Location = new System.Drawing.Point(386, 445);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(245, 62);
            this.btnClear.TabIndex = 8;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(72, 322);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(153, 40);
            this.label4.TabIndex = 9;
            this.label4.Text = "Phone : ";
            // 
            // txtPhone
            // 
            this.txtPhone.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPhone.Location = new System.Drawing.Point(247, 322);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(295, 40);
            this.txtPhone.TabIndex = 10;
            // 
            // txtName
            // 
            this.txtName.Font = new System.Drawing.Font("Tahoma", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtName.Location = new System.Drawing.Point(247, 187);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(295, 40);
            this.txtName.TabIndex = 11;
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.txtName);
            this.groupBox1.Controls.Add(this.txtPhone);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.btnClear);
            this.groupBox1.Controls.Add(this.btnUpdate);
            this.groupBox1.Controls.Add(this.txtAddress);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.comboBox1);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.ForeColor = System.Drawing.Color.White;
            this.groupBox1.Location = new System.Drawing.Point(54, 29);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(724, 513);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Update Data";
            // 
            // UpdateCaptainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(21F, 40F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::GymSystem1.Properties.Resources.subscribe;
            this.ClientSize = new System.Drawing.Size(834, 578);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Tahoma", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(8);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "UpdateCaptainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "UpdateCaptainForm";
            this.Load += new System.EventHandler(this.UpdateCaptainForm_Load);
            this.Move += new System.EventHandler(this.UpdateCaptainForm_Move);
            this.Resize += new System.EventHandler(this.UpdateCaptainForm_Resize);
            ((System.ComponentModel.ISupportInitialize)(this.gymcaptainsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gymSystemDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.connectionDbDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.connectionDbDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gymSystemDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gymcaptainsBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gymSystemDataSet6)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.BindingSource connectionDbDataSetBindingSource;
        private ConnectionDbDataSet connectionDbDataSet;
        private GymSystemDataSet gymSystemDataSet;
        private System.Windows.Forms.BindingSource gymcaptainsBindingSource;
        private GymSystemDataSetTableAdapters.gym_captainsTableAdapter gym_captainsTableAdapter;
        private GymSystemDataSet1 gymSystemDataSet1;
        private System.Windows.Forms.BindingSource gymcaptainsBindingSource1;
        private GymSystemDataSet1TableAdapters.gym_captainsTableAdapter gym_captainsTableAdapter1;
        private GymSystemDataSet6 gymSystemDataSet6;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}