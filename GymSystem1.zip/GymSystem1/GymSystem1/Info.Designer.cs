﻿namespace GymSystem1
{
    partial class InfoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(InfoForm));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.captainsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addNewCaptainToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateCaptainToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteCaptainToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchCaptainToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewCaptainToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.trainersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addNewWorkoutClassToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateTrainerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.searchTrainerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewTrainersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addGymToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.removeGymToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gymAddressToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addGymAddressToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.removeGymAddressToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.captainsToolStripMenuItem,
            this.trainersToolStripMenuItem,
            this.dToolStripMenuItem,
            this.gymAddressToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 32);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.Move += new System.EventHandler(this.menuStrip1_Move);
            this.menuStrip1.Resize += new System.EventHandler(this.menuStrip1_Resize);
            // 
            // captainsToolStripMenuItem
            // 
            this.captainsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addNewCaptainToolStripMenuItem,
            this.updateCaptainToolStripMenuItem,
            this.deleteCaptainToolStripMenuItem,
            this.searchCaptainToolStripMenuItem,
            this.viewCaptainToolStripMenuItem});
            this.captainsToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.captainsToolStripMenuItem.Name = "captainsToolStripMenuItem";
            this.captainsToolStripMenuItem.Size = new System.Drawing.Size(101, 28);
            this.captainsToolStripMenuItem.Text = "Captains";
            // 
            // addNewCaptainToolStripMenuItem
            // 
            this.addNewCaptainToolStripMenuItem.Name = "addNewCaptainToolStripMenuItem";
            this.addNewCaptainToolStripMenuItem.Size = new System.Drawing.Size(247, 28);
            this.addNewCaptainToolStripMenuItem.Text = "Add New Captain";
            this.addNewCaptainToolStripMenuItem.Click += new System.EventHandler(this.addNewCaptainToolStripMenuItem_Click);
            // 
            // updateCaptainToolStripMenuItem
            // 
            this.updateCaptainToolStripMenuItem.Name = "updateCaptainToolStripMenuItem";
            this.updateCaptainToolStripMenuItem.Size = new System.Drawing.Size(247, 28);
            this.updateCaptainToolStripMenuItem.Text = "Update Captain";
            this.updateCaptainToolStripMenuItem.Click += new System.EventHandler(this.updateCaptainToolStripMenuItem_Click);
            // 
            // deleteCaptainToolStripMenuItem
            // 
            this.deleteCaptainToolStripMenuItem.Name = "deleteCaptainToolStripMenuItem";
            this.deleteCaptainToolStripMenuItem.Size = new System.Drawing.Size(247, 28);
            this.deleteCaptainToolStripMenuItem.Text = "Delete Captain";
            this.deleteCaptainToolStripMenuItem.Click += new System.EventHandler(this.deleteCaptainToolStripMenuItem_Click);
            // 
            // searchCaptainToolStripMenuItem
            // 
            this.searchCaptainToolStripMenuItem.Name = "searchCaptainToolStripMenuItem";
            this.searchCaptainToolStripMenuItem.Size = new System.Drawing.Size(247, 28);
            this.searchCaptainToolStripMenuItem.Text = "Search Captain";
            this.searchCaptainToolStripMenuItem.Click += new System.EventHandler(this.searchCaptainToolStripMenuItem_Click);
            // 
            // viewCaptainToolStripMenuItem
            // 
            this.viewCaptainToolStripMenuItem.Name = "viewCaptainToolStripMenuItem";
            this.viewCaptainToolStripMenuItem.Size = new System.Drawing.Size(247, 28);
            this.viewCaptainToolStripMenuItem.Text = "View Captains";
            this.viewCaptainToolStripMenuItem.Click += new System.EventHandler(this.viewCaptainToolStripMenuItem_Click);
            // 
            // trainersToolStripMenuItem
            // 
            this.trainersToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addNewWorkoutClassToolStripMenuItem,
            this.updateTrainerToolStripMenuItem,
            this.toolStripMenuItem1,
            this.searchTrainerToolStripMenuItem,
            this.viewTrainersToolStripMenuItem});
            this.trainersToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trainersToolStripMenuItem.Name = "trainersToolStripMenuItem";
            this.trainersToolStripMenuItem.Size = new System.Drawing.Size(151, 28);
            this.trainersToolStripMenuItem.Text = "Workout Class";
            // 
            // addNewWorkoutClassToolStripMenuItem
            // 
            this.addNewWorkoutClassToolStripMenuItem.Name = "addNewWorkoutClassToolStripMenuItem";
            this.addNewWorkoutClassToolStripMenuItem.Size = new System.Drawing.Size(280, 28);
            this.addNewWorkoutClassToolStripMenuItem.Text = "Add WorkoutClass";
            this.addNewWorkoutClassToolStripMenuItem.Click += new System.EventHandler(this.addNewTrainerToolStripMenuItem_Click);
            // 
            // updateTrainerToolStripMenuItem
            // 
            this.updateTrainerToolStripMenuItem.Name = "updateTrainerToolStripMenuItem";
            this.updateTrainerToolStripMenuItem.Size = new System.Drawing.Size(280, 28);
            this.updateTrainerToolStripMenuItem.Text = "Delete WorkoutClass";
            this.updateTrainerToolStripMenuItem.Click += new System.EventHandler(this.updateTrainerToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(280, 28);
            this.toolStripMenuItem1.Text = "View All Classes";
            this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
            // 
            // searchTrainerToolStripMenuItem
            // 
            this.searchTrainerToolStripMenuItem.Name = "searchTrainerToolStripMenuItem";
            this.searchTrainerToolStripMenuItem.Size = new System.Drawing.Size(280, 28);
            // 
            // viewTrainersToolStripMenuItem
            // 
            this.viewTrainersToolStripMenuItem.Name = "viewTrainersToolStripMenuItem";
            this.viewTrainersToolStripMenuItem.Size = new System.Drawing.Size(280, 28);
            // 
            // dToolStripMenuItem
            // 
            this.dToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addGymToolStripMenuItem,
            this.removeGymToolStripMenuItem});
            this.dToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dToolStripMenuItem.Name = "dToolStripMenuItem";
            this.dToolStripMenuItem.Size = new System.Drawing.Size(64, 28);
            this.dToolStripMenuItem.Text = "Gym";
            this.dToolStripMenuItem.Click += new System.EventHandler(this.dToolStripMenuItem_Click);
            // 
            // addGymToolStripMenuItem
            // 
            this.addGymToolStripMenuItem.Name = "addGymToolStripMenuItem";
            this.addGymToolStripMenuItem.Size = new System.Drawing.Size(212, 28);
            this.addGymToolStripMenuItem.Text = "Add Gym";
            this.addGymToolStripMenuItem.Click += new System.EventHandler(this.addGymToolStripMenuItem_Click);
            // 
            // removeGymToolStripMenuItem
            // 
            this.removeGymToolStripMenuItem.Name = "removeGymToolStripMenuItem";
            this.removeGymToolStripMenuItem.Size = new System.Drawing.Size(212, 28);
            this.removeGymToolStripMenuItem.Text = "Remove Gym";
            // 
            // gymAddressToolStripMenuItem
            // 
            this.gymAddressToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addGymAddressToolStripMenuItem,
            this.removeGymAddressToolStripMenuItem});
            this.gymAddressToolStripMenuItem.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gymAddressToolStripMenuItem.Name = "gymAddressToolStripMenuItem";
            this.gymAddressToolStripMenuItem.Size = new System.Drawing.Size(140, 28);
            this.gymAddressToolStripMenuItem.Text = "Gym Address";
            // 
            // addGymAddressToolStripMenuItem
            // 
            this.addGymAddressToolStripMenuItem.Name = "addGymAddressToolStripMenuItem";
            this.addGymAddressToolStripMenuItem.Size = new System.Drawing.Size(288, 28);
            this.addGymAddressToolStripMenuItem.Text = "Add Gym Address";
            this.addGymAddressToolStripMenuItem.Click += new System.EventHandler(this.addGymAddressToolStripMenuItem_Click);
            // 
            // removeGymAddressToolStripMenuItem
            // 
            this.removeGymAddressToolStripMenuItem.Name = "removeGymAddressToolStripMenuItem";
            this.removeGymAddressToolStripMenuItem.Size = new System.Drawing.Size(288, 28);
            this.removeGymAddressToolStripMenuItem.Text = "Remove Gym Address";
            this.removeGymAddressToolStripMenuItem.Click += new System.EventHandler(this.removeGymAddressToolStripMenuItem_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::GymSystem1.Properties.Resources.captainImg;
            this.pictureBox1.Location = new System.Drawing.Point(2, 73);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(797, 374);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // InfoForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "InfoForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Info";
            this.Move += new System.EventHandler(this.InfoForm_Move);
            this.Resize += new System.EventHandler(this.InfoForm_Resize);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem captainsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addNewCaptainToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateCaptainToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteCaptainToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchCaptainToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewCaptainToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem trainersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addNewWorkoutClassToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateTrainerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchTrainerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewTrainersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem dToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addGymToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem removeGymToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gymAddressToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addGymAddressToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem removeGymAddressToolStripMenuItem;
    }
}