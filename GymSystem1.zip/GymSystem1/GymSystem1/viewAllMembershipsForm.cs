﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymSystem1
{
    public partial class viewAllMembershipsForm : Form
    {
        public viewAllMembershipsForm()
        {
            InitializeComponent();
        }

        private void gym_membershipsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.gym_membershipsBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.dataSet14_viewAllMemberships);

        }

        private void viewAllMembershipsForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dataSet14_viewAllMemberships.gym_memberships' table. You can move, or remove it, as needed.
            this.gym_membershipsTableAdapter.Fill(this.dataSet14_viewAllMemberships.gym_memberships);

        }
    }
}
