﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace GymSystem1
{
    public partial class updateAMembershipForm : Form
    {
        public updateAMembershipForm()
        {
            InitializeComponent();
        }

        private void updateAMembershipForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'gymSystemDataSet13.gym_memberships' table. You can move, or remove it, as needed.
            this.gym_membershipsTableAdapter.Fill(this.gymSystemDataSet13.gym_memberships);

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=AZAZY;Initial Catalog=GymSystem;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("select start_date ,end_date,duration,gym_id,trainee_phone_number from gym_memberships where membership_id=@id", con);
                cmd.Parameters.AddWithValue("@id", comboBox1.Text);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    txtSD.Text = dr[0].ToString();
                    txtED.Text = dr[1].ToString();
                    txtDuration.Text = dr[2].ToString();
                    txtGymID.Text = dr[3].ToString();
                    txtPhone.Text = dr[4].ToString();
                }
                else
                {
                    MessageBox.Show("error");
                }
                con.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=AZAZY;Initial Catalog=GymSystem;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("update gym_memberships set start_date = @sd , end_date = @ed , duration = @d where membership_id = @id", con);
                cmd.Parameters.AddWithValue("@id", int.Parse(comboBox1.Text));
                cmd.Parameters.AddWithValue("@sd", txtSD.Text);
                cmd.Parameters.AddWithValue("@ed", txtED.Text);
                cmd.Parameters.AddWithValue("@d", txtDuration.Text);
                con.Open();
                int rowff = cmd.ExecuteNonQuery();
                if (rowff > 0)
                {
                    MessageBox.Show("updated");
                }
                else
                {
                    MessageBox.Show("error");
                }
                con.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtDuration.Text = "";
            txtED.Text = "";
            txtGymID.Text = "";
            txtPhone.Text = "";
            txtSD.Text = "";
        }
    }
}
