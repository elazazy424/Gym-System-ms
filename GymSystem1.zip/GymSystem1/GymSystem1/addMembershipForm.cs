﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.Data.SqlClient;

namespace GymSystem1
{
    public partial class addMembershipForm : Form
    {
        public addMembershipForm()
        {
            InitializeComponent();
        }

        private void addMembershipForm_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'gymSystemDataSet11.Gym' table. You can move, or remove it, as needed.
            this.gymTableAdapter.Fill(this.gymSystemDataSet11.Gym);
            // TODO: This line of code loads data into the 'gymSystemDataSet10.trainees' table. You can move, or remove it, as needed.
            this.traineesTableAdapter.Fill(this.gymSystemDataSet10.trainees);

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtED.Text = "";
            txtID.Text = "";          
            txtDuration.Text = "";
            txtSD.Text = "";
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=AZAZY;Initial Catalog=GymSystem;Integrated Security=True");
                SqlCommand cmd = new SqlCommand("insert into gym_memberships values(@id , @sd , @ed,@duration,@gym_id,@phone)", con);
                cmd.Parameters.AddWithValue("@id", int.Parse(txtID.Text));
                cmd.Parameters.AddWithValue("@sd", txtSD.Text);
                cmd.Parameters.AddWithValue("@ed", txtED.Text);
                cmd.Parameters.AddWithValue("@duration", txtDuration.Text);
                cmd.Parameters.AddWithValue("@gym_id", int.Parse(comboBox2.Text));
                cmd.Parameters.AddWithValue("@phone", comboBox1.Text);
                con.Open();
                int rowff = cmd.ExecuteNonQuery();
                if (rowff > 0)
                {
                    MessageBox.Show("added");
                }
                else
                {
                    MessageBox.Show("error");
                }
                con.Close();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
